package com.App;

public class Catagory {
	static String fruits="Fruits & Vegetables";
	static String cakes="Bakery, Cakes & Dairy";
	static String beverages="Beverages";
	static String snacks="Snacks & Branded Foods";
	static String babyCare="Baby Care";
	static String kitchen="kitchen, Garden & Pets";
	static String bueaty="Beauty & Hygiene";
	
}
